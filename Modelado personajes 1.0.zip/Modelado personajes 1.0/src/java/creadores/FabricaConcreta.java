/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creadores;

import javax.swing.JOptionPane;

/**
 *
 * @author Usuario
 */
public class FabricaConcreta extends CreadorAbstracto {

    @Override
    public Fabrica crearFabrica(String personaje) {
        Fabrica fab=null;

        switch (personaje) {
            case "Humano":
                fab = FabricaHumano.getInstance();
                break;
            case "Elfo":
                fab = FabricaElfo.getInstance();
                break;
            case "Enano":
                fab = FabricaEnano.getInstance();
                break;
            case "Hechicero":
                fab = FabricaHechicero.getInstance();
                break;
            default:
                JOptionPane.showMessageDialog(null, "No se eligio personaje");
        }
        return fab;
    }
}
