/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creadores;

import complementos.Arma;
import complementos.Cuerpo;
import complementos.Escudo;
import complementos.Montura;
import creadores.Fabrica;
import creadores.FabricaElfo;
import creadores.FabricaEnano;
import creadores.FabricaHechicero;
import creadores.FabricaHumano;

/**
 *
 * @author Andres
 */
public class CreadorConcreto {

    String personaje;
    Fabrica fabrica = null;
    Escudo escudo;
    Arma arma;
    Cuerpo cuerpo;
    Montura montura;
    protected String escudos;
    protected String cuerpos;
    protected String monturas;
    protected String armas;

    public CreadorConcreto(String personaje) {
        this.personaje = personaje;
    }

    public void generador() {
        Fabrica fabrica;
        FabricaConcreta creador= new FabricaConcreta();
        fabrica=creador.crearFabrica(personaje);

        arma = fabrica.crearArma();
        cuerpo = fabrica.crearCuerpo();
        montura = fabrica.crearMontura();
        escudo = fabrica.crearEscudo();
        escudos = escudo.operacion();
        cuerpos = cuerpo.operacion();
        monturas = montura.operacion();
        armas = arma.operacion();

    }

    public String getEscudos() {
        return escudos;
    }

    public String getCuerpos() {
        return cuerpos;
    }

    public String getMonturas() {
        return monturas;
    }

    public String getArmas() {
        return armas;
    }

}
